"""Candidate-memory diagnostic. No question generation, target-aware selection or future queries."""
import argparse, csv, hashlib, json, os, time
from pathlib import Path
import numpy as np
os.environ.setdefault('USE_TF','0'); os.environ.setdefault('USE_FLAX','0')
ROOT=Path(__file__).resolve().parent
MODEL='Salesforce/blip-itm-large-coco'
REVISION='19502f1e215844f7e48bd48473f86932486d3441'
METHODS=['current','original_only','original_current_rrf','previous_current_rrf','all_history_rrf','history_quota']
BUDGETS=[50,100]
STAGES=[4,9]

def read(p):return json.loads(Path(p).read_text())
def save(p,x):
 p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csvsave(p,rows):
 with Path(p).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def order(scores):return np.argsort(-np.asarray(scores),kind='stable')
def ranks(scores):
 o=order(scores);r=np.empty(len(o),dtype=np.int32);r[o]=np.arange(1,len(o)+1);return r

def available_queries(dialog,t):
 # Original through current only. Exact repeated descriptions receive one vote.
 return list(dict.fromkeys(dialog[:t+1]))

def quota_pool(rank_orders,budget):
 """Keep current top half, then round-robin historical top-B lists, most recent first."""
 selected=list(map(int,rank_orders[-1][:budget//2]));seen=set(selected)
 historical=[list(map(int,o[:budget])) for o in rank_orders[:-1]][::-1]
 for depth in range(budget):
  for candidates in historical:
   candidate=candidates[depth]
   if candidate not in seen:selected.append(candidate);seen.add(candidate)
   if len(selected)==budget:return np.array(selected,dtype=np.int32)
 for candidate in rank_orders[-1]:
  if int(candidate) not in seen:selected.append(int(candidate));seen.add(int(candidate))
  if len(selected)==budget:break
 return np.array(selected,dtype=np.int32)

def candidate_pools(dialog,t,rank_cache,budget):
 texts=available_queries(dialog,t)
 rr=[rank_cache[x] for x in texts]
 current=rank_cache[dialog[t]];original=rank_cache[dialog[0]]
 def fused(queries):return order(sum(1/(60+rank_cache[x].astype(float)) for x in dict.fromkeys(queries)))[:budget]
 return {'current':np.argsort(current)[:budget], 'original_only':np.argsort(original)[:budget],
 'original_current_rrf':fused([dialog[0],dialog[t]]),
 'previous_current_rrf':fused([dialog[t-1],dialog[t]]),
 'all_history_rrf':fused(texts),
 'history_quota':quota_pool([np.argsort(rank_cache[x]) for x in list(dict.fromkeys(dialog[:t]))]+[np.argsort(current)],budget)}

def select_mmr(pool,current_ranks,vectors,count=10,weight=.7):
 """Common diagnostic selector: current-query rank relevance plus image-vector diversity."""
 pool=np.asarray(pool);relevance=1/(60+current_ranks[pool].astype(float))
 spread=np.ptp(relevance);relevance=(relevance-relevance.min())/spread if spread>1e-12 else np.zeros(len(pool))
 similarity=np.clip(vectors[pool]@vectors[pool].T,-1,1)
 # Fixed corpus-ID tie break, independent of pool construction and target.
 selected=[];available=np.ones(len(pool),bool)
 for _ in range(min(count,len(pool))):
  score=relevance.copy() if not selected else weight*relevance-(1-weight)*similarity[:,selected].max(axis=1)
  choices=np.where(available)[0]
  best=choices[np.lexsort((pool[choices],-score[choices]))[0]]
  selected.append(int(best));available[best]=False
 return pool[selected]

def run(data,output,split,device):
 import torch
 from transformers import AutoTokenizer,BlipForImageTextRetrieval
 from torch.nn.functional import normalize
 output.mkdir(parents=True,exist_ok=True)
 manifest=read(ROOT/'memory_manifest.json')
 for name,expected in manifest['data_sha256'].items():
  if digest(data/name)!=expected:raise ValueError('Data checksum mismatch: '+name)
 queries=read(data/'queries.json');corpus=read(data/'corpus.json');indices=manifest['splits'][split]
 config=dict(split=split,indices=indices,stages=STAGES,budgets=BUDGETS,methods=METHODS,model=MODEL,revision=REVISION,rrf_k=60,mmr_weight=.7,selected_images=10,script_sha256=digest(__file__),manifest_sha256=digest(ROOT/'memory_manifest.json'),data_sha256=manifest['data_sha256'])
 if (output/'config.json').exists() and read(output/'config.json')!=config:raise ValueError('Configuration changed. Choose a new RUN_NAME.')
 save(output/'config.json',config)
 device=device or ('cuda' if torch.cuda.is_available() else 'cpu');start=time.perf_counter()
 ids,tensor=torch.load(data/'corpus_blip.pth',map_location='cpu',weights_only=True)
 if not torch.equal(ids,torch.arange(50000)) or tensor.shape!=(50000,256):raise ValueError('Unexpected corpus cache.')
 if not torch.isfinite(tensor).all() or not torch.allclose(tensor.norm(dim=1),torch.ones(50000),atol=1e-4):raise ValueError('Invalid image embeddings.')
 if len(corpus)!=50000 or len(set(corpus))!=50000:raise ValueError('Invalid corpus IDs.')
 vectors=tensor.numpy();gpu_vectors=tensor.to(device);id_lookup={s:i for i,s in enumerate(corpus)}
 texts=list(dict.fromkeys(text for i in indices for text in queries[i]['dialog'][:10]))
 # Persist small text embeddings, not huge per-query rankings. Reuse after interruption.
 cache_path=output/'text_features.npz';feature_cache={}
 if cache_path.exists():
  with np.load(cache_path,allow_pickle=False) as f:feature_cache=dict(zip(f['texts'].tolist(),f['features']))
 pending=[x for x in texts if x not in feature_cache]
 truncated=read(output/'truncated_queries.json') if (output/'truncated_queries.json').exists() else []
 if pending:
  tokenizer=AutoTokenizer.from_pretrained(MODEL,revision=REVISION)
  model=BlipForImageTextRetrieval.from_pretrained(MODEL,revision=REVISION).to(device).eval()
  for offset in range(0,len(pending),16):
   batch=pending[offset:offset+16]
   truncated.extend(x for x in batch if len(tokenizer(x)['input_ids'])>tokenizer.model_max_length)
   tokens=tokenizer(batch,padding=True,truncation=True,return_tensors='pt').to(device)
   with torch.inference_mode():
    hidden=model.text_encoder(input_ids=tokens.input_ids,attention_mask=tokens.attention_mask,return_dict=True).last_hidden_state
    feats=normalize(model.text_proj(hidden[:,0,:]),dim=-1).float().cpu().numpy()
   feature_cache.update(zip(batch,feats))
   temp=output/'text_features.tmp.npz'
   np.savez_compressed(temp,texts=np.array(list(feature_cache)),features=np.array(list(feature_cache.values())))
   temp.replace(cache_path);save(output/'truncated_queries.json',list(dict.fromkeys(truncated)))
   print(f'Text embeddings saved: {len(feature_cache)}/{len(texts)}',flush=True)
  del model
  if device.startswith('cuda'):torch.cuda.empty_cache()
 results=[];examples=[];controls=[]
 for num,index in enumerate(indices,1):
  item=queries[index];target=id_lookup[item['img']];dialog=item['dialog'];unique=available_queries(dialog,9)
  with torch.inference_mode():scores=(torch.from_numpy(np.array([feature_cache[x] for x in unique])).to(device)@gpu_vectors.T).float().cpu().numpy()
  rank_cache={x:ranks(s) for x,s in zip(unique,scores)}
  for t in STAGES:
   current_ranks=rank_cache[dialog[t]];past_texts=available_queries(dialog,t-1)
   full={'current':current_ranks,'original_only':rank_cache[dialog[0]],'original_current_rrf':ranks(sum(1/(60+rank_cache[x].astype(float)) for x in dict.fromkeys([dialog[0],dialog[t]])))}
   for method,ranking in full.items():controls.append(dict(source_index=index,answers=t,method=method,target_rank=int(ranking[target])))
   for budget in BUDGETS:
    pools=candidate_pools(dialog,t,rank_cache,budget);base=set(map(int,pools['current']))
    previously_seen=any(rank_cache[x][target]<=budget for x in past_texts)
    for method,pool in pools.items():
     selected=select_mmr(pool,current_ranks,vectors);ordered10=pool[:10]
     assert len(pool)==budget and len(set(pool))==budget and len(set(selected))==10
     selected_vectors=vectors[selected];sim=selected_vectors@selected_vectors.T
     row=dict(source_index=index,answers=t,budget=budget,method=method,target_in_pool=int(target in pool),target_in_selected10=int(target in selected),target_in_ordered10=int(target in ordered10),previous_target_in_pool=int(previously_seen),new_vs_current=len(set(map(int,pool))-base),mean_selected_cosine=float(sim[np.triu_indices(10,1)].mean()))
     results.append(row)
     examples.append(dict(**row,target_id=target,target_path=item['img'],original=dialog[0],current=dialog[t],history=[dict(answers=j,description=dialog[j],target_rank=int(rank_cache[dialog[j]][target])) for j in range(t+1)],pool_ids=list(map(int,pool)),selected_ids=list(map(int,selected)),ordered10_ids=list(map(int,ordered10)),selected_paths=[corpus[int(x)] for x in selected],selected_current_ranks=[int(current_ranks[x]) for x in selected]))
  print(f'Evaluated {num}/{len(indices)} targets',flush=True)
 csvsave(output/'per_target.csv',results);csvsave(output/'retrieval_controls.csv',controls);save(output/'examples.json',examples)
 summaries=[];comparisons=[]
 for t in STAGES:
  for budget in BUDGETS:
   base={r['source_index']:r for r in results if r['answers']==t and r['budget']==budget and r['method']=='current'}
   for method in METHODS:
    rows=[r for r in results if r['answers']==t and r['budget']==budget and r['method']==method]
    summaries.append(dict(answers=t,budget=budget,method=method,targets=len(rows),pool_coverage_pct=100*np.mean([r['target_in_pool'] for r in rows]),selected10_coverage_pct=100*np.mean([r['target_in_selected10'] for r in rows]),ordered10_coverage_pct=100*np.mean([r['target_in_ordered10'] for r in rows]),mean_new_vs_current=np.mean([r['new_vs_current'] for r in rows])))
    for baseline in ['current','original_current_rrf']:
     if method==baseline:continue
     base={r['source_index']:r for r in results if r['answers']==t and r['budget']==budget and r['method']==baseline}
     for metric in ['target_in_pool','target_in_selected10']:
      delta=np.array([r[metric]-base[r['source_index']][metric] for r in rows]);rng=np.random.default_rng(1111)
      boot=rng.choice(delta,(2000,len(delta)),replace=True).mean(axis=1)*100
      comparisons.append(dict(answers=t,budget=budget,method=method,baseline=baseline,metric=metric,recovered=int((delta==1).sum()),lost=int((delta==-1).sum()),delta_pp=100*delta.mean(),ci95_low=float(np.quantile(boot,.025)),ci95_high=float(np.quantile(boot,.975))))
 csvsave(output/'summary.csv',summaries);csvsave(output/'comparisons.csv',comparisons)
 control_summary=[]
 for t in STAGES:
  for method in full:
   rr=[r['target_rank'] for r in controls if r['answers']==t and r['method']==method]
   control_summary.append(dict(answers=t,method=method,targets=len(rr),recall_at_1=100*np.mean(np.array(rr)<=1),recall_at_10=100*np.mean(np.array(rr)<=10),recall_at_50=100*np.mean(np.array(rr)<=50),mrr=float(np.mean(1/np.array(rr))),median_rank=float(np.median(rr))))
 csvsave(output/'control_summary.csv',control_summary)
 save(output/'timing.json',dict(seconds=time.perf_counter()-start,device=device,gpu=torch.cuda.get_device_name(0) if device.startswith('cuda') else None,unique_texts=len(texts),truncated_texts=len(set(truncated))))
 (output/'README.txt').write_text('Fixed-state candidate-memory diagnostic. Results reconstruct searches from saved descriptions; they do not replay actual stored result lists. Stages after 4 and 9 answers use no future descriptions. Compare equal budgets. MMR is a shared diagnostic selector, not PlugIR clustering or A2R DPP. Target information is used only for evaluation and inspection. Target coverage does not measure question utility or correctness of remembered details. Historical summaries are not verified user facts. Multiple exploratory comparisons; confidence intervals are not multiplicity-adjusted. Holdout must not be used to choose settings.\n')
 print('Complete. Results:',output,flush=True)

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--data',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--split',choices=['smoke','development','holdout'],default='development');a.add_argument('--device',default=None);v=a.parse_args();run(v.data,v.output,v.split,v.device)
