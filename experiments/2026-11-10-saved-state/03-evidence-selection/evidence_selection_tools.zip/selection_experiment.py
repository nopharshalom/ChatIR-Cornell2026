"""Compare selectors inside fixed saved pools. Target labels are evaluation-only."""
import argparse,json,time,hashlib
from pathlib import Path
import numpy as np
import memory_experiment as m
POOLS=['original_current_rrf','all_history_rrf']
SELECTORS=['current_mmr','history_mmr','history_top10','split_5_5']

def select(pool,current_ranks,fused_ranks,past_ranks,vectors):
 pool=np.asarray(pool,dtype=np.int32)
 current_order=pool[np.lexsort((pool,current_ranks[pool]))]
 past_order=pool[np.lexsort((pool,past_ranks[pool]))]
 # Exactly five slots selected on current relevance, then five unseen historical candidates.
 split=list(map(int,current_order[:5]));seen=set(split)
 for candidate in past_order:
  if int(candidate) not in seen:split.append(int(candidate));seen.add(int(candidate))
  if len(split)==10:break
 return dict(current_mmr=m.select_mmr(pool,current_ranks,vectors),
             history_mmr=m.select_mmr(pool,fused_ranks,vectors),
             history_top10=pool[np.lexsort((pool,fused_ranks[pool]))][:10],
             split_5_5=np.array(split,dtype=np.int32))

def run(data,source,output,split,device='cpu',frozen_path=None):
 import torch
 output.mkdir(parents=True,exist_ok=True)
 manifest=m.read(m.ROOT/'memory_manifest.json');source_config=m.read(source/'config.json')
 assert source_config['split']==split and source_config['indices']==manifest['splits'][split], 'Wrong source split or target sample'
 assert source_config['model']==m.MODEL and source_config['revision']==m.REVISION
 assert source_config['rrf_k']==60 and source_config['mmr_weight']==.7
 assert source_config['data_sha256']==manifest['data_sha256']
 for name,expected in manifest['data_sha256'].items():
  if m.digest(data/name)!=expected:raise ValueError('Data mismatch: '+name)
 frozen=m.read(frozen_path) if frozen_path else None
 if split=='holdout':
  if frozen is None:raise ValueError('Freeze a pool and selector before running holdout.')
  assert frozen['pool'] in POOLS and frozen['selector'] in SELECTORS[1:]
  pools=[frozen['pool']];selectors=list(dict.fromkeys(['current_mmr','history_top10',frozen['selector']]))
 else:pools=POOLS;selectors=SELECTORS
 config=dict(split=split,pools=pools,selectors=selectors,budget=50,stages=[4,9],primary_stage=9,primary_metric='selected10_coverage',mmr_weight=.7,rrf_k=60,frozen_choice=frozen,source_config_sha256=m.digest(source/'config.json'),source_examples_sha256=m.digest(source/'examples.json'),features_sha256=m.digest(source/'text_features.npz'),script_sha256=m.digest(__file__),memory_script_sha256=m.digest(m.ROOT/'memory_experiment.py'))
 if (output/'config.json').exists() and m.read(output/'config.json')!=config:raise ValueError('Settings changed: choose a new RUN_NAME.')
 m.save(output/'config.json',config)
 ids,tensor=torch.load(data/'corpus_blip.pth',map_location='cpu',weights_only=True)
 assert torch.equal(ids,torch.arange(50000)) and tensor.shape==(50000,256)
 assert torch.isfinite(tensor).all() and torch.allclose(tensor.norm(dim=1),torch.ones(50000),atol=1e-4)
 vectors=tensor.numpy();image_gpu=tensor.to(device);queries=m.read(data/'queries.json');corpus=m.read(data/'corpus.json')
 with np.load(source/'text_features.npz',allow_pickle=False) as f:features=dict(zip(f['texts'].tolist(),f['features']))
 source_rows=m.read(source/'examples.json');lookup={(r['source_index'],r['answers'],r['method']):r for r in source_rows if r['budget']==50}
 rows=[];examples=[];started=time.perf_counter()
 for num,index in enumerate(manifest['splits'][split],1):
  dialog=queries[index]['dialog'];texts=m.available_queries(dialog,9)
  with torch.inference_mode():scores=(torch.from_numpy(np.array([features[x] for x in texts])).to(device)@image_gpu.T).float().cpu().numpy()
  cache={x:m.ranks(s) for x,s in zip(texts,scores)}
  def fused(qs):return m.ranks(sum(1/(60+cache[x].astype(float)) for x in dict.fromkeys(qs)))
  for t in [4,9]:
   current=cache[dialog[t]];current_source=lookup[index,t,'current'];target=current_source['target_id']
   assert corpus[target]==queries[index]['img']
   for pool_method in pools:
    source_row=lookup[index,t,pool_method];pool=np.array(source_row['pool_ids'],dtype=np.int32)
    histories=[dialog[0],dialog[t]] if pool_method=='original_current_rrf' else dialog[:t+1]
    past=[dialog[0]] if pool_method=='original_current_rrf' else dialog[:t]
    fused_ranks=fused(histories);past_ranks=fused(past)
    selections=select(pool,current,fused_ranks,past_ranks,vectors)
    if list(map(int,selections['current_mmr']))!=source_row['selected_ids']:
     raise ValueError(f'Baseline selection mismatch for {index}_{t}/{pool_method}. Use the same device type as the previous run; do not silently compare changed baselines.')
    if list(map(int,selections['history_top10']))!=source_row['ordered10_ids']:
     raise ValueError('Fused ranking does not reproduce source pool ordering.')
    for selector in selectors:
     selected=selections[selector];assert len(set(selected))==10 and set(selected).issubset(set(pool))
     selected_vectors=vectors[selected];sims=selected_vectors@selected_vectors.T
     row=dict(source_index=index,answers=t,pool_method=pool_method,selector=selector,pool_size=len(pool),target_in_pool=int(target in pool),target_in_selected10=int(target in selected),recovered_by_pool=int(target in pool and not current_source['target_in_pool']),recovered_and_selected=int(target in selected and not current_source['target_in_pool']),mean_pairwise_cosine=float(sims[np.triu_indices(10,1)].mean()))
     rows.append(row);examples.append(dict(**row,target_id=target,target_path=queries[index]['img'],original=dialog[0],current=dialog[t],selected_ids=list(map(int,selected)),selected_paths=[corpus[x] for x in selected],selected_current_ranks=[int(current[x]) for x in selected],selected_fused_ranks=[int(fused_ranks[x]) for x in selected]))
  print(f'Evaluated selectors for {num}/{len(manifest["splits"][split])} targets',flush=True)
 summary=[];comparisons=[]
 for t in [4,9]:
  for pool_method in pools:
   for selector in selectors:
    group=[r for r in rows if r['answers']==t and r['pool_method']==pool_method and r['selector']==selector]
    summary.append(dict(answers=t,pool_method=pool_method,selector=selector,targets=len(group),pool_coverage_pct=100*np.mean([r['target_in_pool'] for r in group]),selected10_coverage_pct=100*np.mean([r['target_in_selected10'] for r in group]),pool_recoveries=sum(r['recovered_by_pool'] for r in group),pool_recoveries_selected=sum(r['recovered_and_selected'] for r in group),mean_pairwise_cosine=np.mean([r['mean_pairwise_cosine'] for r in group])))
    for ref in ['current_mmr','history_top10']:
     if ref==selector:continue
     base={r['source_index']:r for r in rows if r['answers']==t and r['pool_method']==pool_method and r['selector']==ref}
     delta=np.array([r['target_in_selected10']-base[r['source_index']]['target_in_selected10'] for r in group]);rng=np.random.default_rng(1112);boot=rng.choice(delta,(2000,len(delta))).mean(axis=1)*100
     comparisons.append(dict(answers=t,pool_method=pool_method,selector=selector,baseline=ref,recovered=int((delta==1).sum()),lost=int((delta==-1).sum()),delta_pp=100*delta.mean(),ci95_low=float(np.quantile(boot,.025)),ci95_high=float(np.quantile(boot,.975))))
 m.csvsave(output/'per_target.csv',rows);m.csvsave(output/'summary.csv',summary);m.csvsave(output/'comparisons.csv',comparisons);m.save(output/'examples.json',examples)
 m.save(output/'timing.json',dict(seconds=time.perf_counter()-started,device=device))
 (output/'README.txt').write_text('Fixed saved 50-image pools, exactly 10 selected. No new questions, answers, Qwen calls or images used by an agent. History-MMR changes only the relevance ranking used by the prior MMR selector; rank relevance is 1/(60+rank), normalized within the pool, and weight remains 0.7. Split allocation uses 5 current-ranked images then 5 unseen historical-ranked images within the SAME pool. Target IDs are evaluation-only. Coverage is not question quality. Pairwise cosine is an embedding diversity diagnostic, not semantic usefulness. Bootstrap intervals are exploratory and not multiplicity-adjusted.\n')
 print('Complete:',output,flush=True)

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--data',type=Path,required=True);a.add_argument('--source',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--split',choices=['smoke','development','holdout'],default='development');a.add_argument('--device',default='cpu');a.add_argument('--frozen',type=Path);v=a.parse_args();run(v.data,v.source,v.output,v.split,v.device,v.frozen)
