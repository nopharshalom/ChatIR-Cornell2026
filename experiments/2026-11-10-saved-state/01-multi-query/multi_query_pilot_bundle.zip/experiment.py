"""Paired retrieval experiments on fixed, saved PlugIR conversation states."""
import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import random
import time

os.environ.setdefault('USE_TF', '0')
os.environ.setdefault('USE_FLAX', '0')
ROOT = Path(__file__).resolve().parent
MODEL = 'Qwen/Qwen3-4B-Instruct-2507'
REVISION = 'cdbee75f17c01a7cc42f958dc650907174af0554'
BLIP = 'Salesforce/blip-itm-large-coco'
BLIP_REVISION = '19502f1e215844f7e48bd48473f86932486d3441'
SYSTEM = '''Create two complementary short search descriptions for image retrieval.
Use only facts in the supplied description. Never invent objects, colors, people,
actions, counts or relationships. Preserve the main subject in both variants.
Variant 1 emphasizes the main subject and its attributes. Variant 2 emphasizes
the main subject and its setting or relationships, where these are supplied.
When there is little information, use faithful alternative wording.
Write at most 35 words per variant. Make the variants different from each other
and from the supplied description. Return only a JSON object with keys
"variant_1" and "variant_2", each containing one string.'''
METHODS = {'A': 'Current alone', 'B': 'Current + two variants',
           'C': 'Original + current', 'D': 'Original + current + variant 1'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    temporary.replace(path)


def write_csv(path, rows):
    with Path(path).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def prepare(output, split):
    output.mkdir(parents=True, exist_ok=True)
    bundle = read(ROOT / 'bundle_manifest.json')
    for name, expected in bundle['sha256'].items():
        if digest(ROOT / name) != expected:
            raise ValueError(f'Bundle integrity check failed: {name}')
    queries = read(ROOT / 'queries.json')
    corpus = read(ROOT / 'corpus.json')
    indices = bundle['splits'][split]
    if len(corpus) != 50000 or len(set(corpus)) != 50000:
        raise ValueError('Expected 50,000 unique candidate image IDs.')
    rows = []
    for index in indices:
        item = queries[index]
        target_id = corpus.index(item['img'])
        for answers in (4, 9):
            rows.append(dict(key=f'{index}_{answers}', source_index=index,
                             answers=answers, target_path=item['img'], target_id=target_id,
                             original=item['dialog'][0], current=item['dialog'][answers]))
    config = dict(split=split, indices=indices, answers=[4, 9], candidate_count=50000,
                  qwen_model=MODEL, qwen_revision=REVISION, blip_model=BLIP,
                  blip_revision=BLIP_REVISION, rrf_k=60, max_tokens=256,
                  temperature=0, seed=1110, prompt_sha256=hashlib.sha256(SYSTEM.encode()).hexdigest(),
                  source_sha256=bundle['sha256'], experiment_sha256=digest(__file__))
    config_path = output / 'config.json'
    if config_path.exists() and read(config_path) != config:
        raise ValueError('This output folder belongs to a different configuration. Choose a new RUN_NAME.')
    save(config_path, config)
    save(output / 'states.json', rows)
    print(f'{split}: {len(indices)} targets, {len(rows)} saved states, 50,000 candidates.', flush=True)
    return rows


def parse_variants(raw, current):
    raw = raw.strip()
    if raw.startswith('```'):
        raw = '\n'.join(raw.splitlines()[1:-1])
    item = json.loads(raw)
    variants = [item['variant_1'], item['variant_2']]
    for value in variants:
        if not isinstance(value, str) or not value.strip() or len(value.split()) > 45:
            raise ValueError('Variants must be nonempty strings of at most 45 words.')
    normalized = [' '.join(v.lower().split()).strip(' .') for v in [current, *variants]]
    if len(set(normalized)) != 3:
        raise ValueError('Duplicate variants or an unchanged query.')
    return [value.strip() for value in variants]


def generate(output, split):
    rows = prepare(output, split)
    cache_path = output / 'generated.json'
    cached = read(cache_path) if cache_path.exists() else {}
    pending = [row for row in rows if row['key'] not in cached]
    if not pending:
        print('All query variants are already saved. Reusing them.', flush=True)
        return
    from cuda_llm import LocalCUDAChat
    client = LocalCUDAChat(MODEL, REVISION, 1110, output)
    failures = []
    try:
        for number, row in enumerate(pending, 1):
            # No original query, image, target identifier, rank or future state enters this prompt.
            messages = [dict(role='system', content=SYSTEM),
                        dict(role='user', content='Description:\n' + row['current'])]
            started = time.perf_counter()
            errors = []
            for attempt in range(2):
                response = client.create(messages=messages, max_tokens=256, temperature=0, seed=1110)
                raw = response['choices'][0]['message']['content']
                try:
                    variants = parse_variants(raw, row['current'])
                except (ValueError, KeyError, TypeError) as exc:
                    errors.append(str(exc))
                    messages.extend([dict(role='assistant', content=raw),
                                     dict(role='user', content='Correct the format and provide two distinct, faithful short descriptions as the requested JSON object.')])
                    continue
                cached[row['key']] = dict(variant_1=variants[0], variant_2=variants[1],
                                          current=row['current'], attempts=attempt+1,
                                          seconds=time.perf_counter()-started)
                save(cache_path, cached)
                break
            else:
                failures.append(dict(key=row['key'], errors=errors, raw=raw))
                save(output / 'generation_failures.json', failures)
            print(f'{number}/{len(pending)} pending states processed; {len(cached)}/{len(rows)} saved.', flush=True)
    finally:
        client.close()
    if failures:
        raise RuntimeError('Some variants failed validation. Completed states are saved. Inspect generation_failures.json and rerun this cell. No failed target will be silently excluded.')


def ranks_from_scores(scores):
    import numpy as np
    # Stable ties are resolved by corpus index for every method.
    order = np.argsort(-scores, kind='stable')
    ranks = np.empty(len(order), dtype=np.int32)
    ranks[order] = np.arange(1, len(order)+1)
    return ranks


def fused_scores(rank_lists, k=60):
    import numpy as np
    return sum(1.0 / (k + np.asarray(ranks, dtype=np.float64)) for ranks in rank_lists)


def evaluate(output, split, device):
    import numpy as np
    import torch
    from torch.nn.functional import normalize
    from transformers import AutoTokenizer, BlipForImageTextRetrieval
    rows = prepare(output, split)
    generated = read(output / 'generated.json')
    if any(row['key'] not in generated for row in rows):
        raise ValueError('Generate valid variants for every state before evaluation.')
    for row in rows:
        if generated[row['key']]['current'] != row['current']:
            raise ValueError('Cached variant belongs to a different source query.')
    device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
    started = time.perf_counter()
    ids, vectors = torch.load(ROOT / 'corpus_blip.pth', map_location='cpu', weights_only=True)
    if not torch.equal(ids, torch.arange(50000)) or vectors.shape != (50000, 256):
        raise ValueError('Image cache IDs or dimensions do not match the corpus.')
    if not torch.isfinite(vectors).all() or not torch.allclose(vectors.norm(dim=1), torch.ones(50000), atol=1e-4):
        raise ValueError('Expected finite, normalized image vectors.')
    vectors = vectors.to(device)
    tokenizer = AutoTokenizer.from_pretrained(BLIP, revision=BLIP_REVISION)
    model = BlipForImageTextRetrieval.from_pretrained(BLIP, revision=BLIP_REVISION).to(device).eval()
    texts = list(dict.fromkeys(text for row in rows for text in
                 [row['original'], row['current'], generated[row['key']]['variant_1'], generated[row['key']]['variant_2']]))
    rank_cache = {}
    truncated = []
    model_load_seconds = time.perf_counter()-started
    encoding_start = time.perf_counter()
    for offset in range(0, len(texts), 16):
        batch = texts[offset:offset+16]
        truncated.extend(text for text in batch if len(tokenizer(text)['input_ids']) > tokenizer.model_max_length)
        tokens = tokenizer(batch, padding=True, truncation=True, return_tensors='pt').to(device)
        with torch.inference_mode():
            hidden = model.text_encoder(input_ids=tokens.input_ids, attention_mask=tokens.attention_mask, return_dict=True).last_hidden_state
            features = normalize(model.text_proj(hidden[:, 0, :]), dim=-1)
            scores = (features @ vectors.T).float().cpu().numpy()
        for text, score in zip(batch, scores):
            rank_cache[text] = ranks_from_scores(score)
        print(f'Encoded {min(offset+16,len(texts))}/{len(texts)} unique search descriptions.', flush=True)
    encoding_seconds = time.perf_counter()-encoding_start
    results = []
    examples = []
    fusion_start = time.perf_counter()
    for row in rows:
        variants = generated[row['key']]
        methods = {'A': [row['current']],
                   'B': [row['current'], variants['variant_1'], variants['variant_2']],
                   'C': [row['original'], row['current']],
                   'D': [row['original'], row['current'], variants['variant_1']]}
        for method, queries in methods.items():
            # Identical searches do not receive extra votes if original and current coincide.
            unique_queries = list(dict.fromkeys(queries))
            rank_lists = [rank_cache[text] for text in unique_queries]
            ranks = rank_lists[0] if len(rank_lists)==1 else ranks_from_scores(fused_scores(rank_lists))
            results.append(dict(source_index=row['source_index'], answers=row['answers'],
                                target_path=row['target_path'], method=method,
                                target_rank=int(ranks[row['target_id']]), search_count=len(unique_queries)))
            examples.append(dict(key=row['key'], method=method, queries=unique_queries,
                                 top_10_corpus_ids=np.argsort(ranks)[:10].tolist()))
    write_csv(output / 'ranks.csv', results)
    save(output / 'top10.json', examples)
    review = [dict(source_index=r['source_index'], answers=r['answers'], original=r['original'],
                   current=r['current'], variant_1=generated[r['key']]['variant_1'],
                   variant_2=generated[r['key']]['variant_2']) for r in rows]
    write_csv(output / 'queries_for_review.csv', review)
    timing = dict(device=device, model_load_seconds=model_load_seconds, text_encoding_and_ranking_seconds=encoding_seconds,
                  fusion_seconds=time.perf_counter()-fusion_start,
                  generation_request_seconds=sum(generated[r['key']]['seconds'] for r in rows),
                  generation_attempts=sum(generated[r['key']]['attempts'] for r in rows),
                  unique_text_queries=len(texts), truncated_text_count=len(truncated),
                  python=platform.python_version(), packages={n:importlib.metadata.version(n) for n in ('torch','transformers','numpy')})
    if device.startswith('cuda'):
        timing['gpu'] = torch.cuda.get_device_name(device)
    save(output / 'timing.json', timing)
    save(output / 'truncated_queries.json', truncated)
    summarize(output, results)


def summarize(output, results):
    import numpy as np
    summaries, comparisons = [], []
    for answers in (4, 9):
        ranks = {}
        for method, label in METHODS.items():
            selected = sorted((r for r in results if r['answers']==answers and r['method']==method), key=lambda r:r['source_index'])
            values = np.array([r['target_rank'] for r in selected])
            ranks[method] = values
            summaries.append(dict(answers=answers, method=method, description=label, targets=len(values),
                                  recall_at_1=100*float(np.mean(values<=1)),
                                  recall_at_10=100*float(np.mean(values<=10)),
                                  recall_at_50=100*float(np.mean(values<=50)),
                                  mrr=float(np.mean(1/values)), median_rank=float(np.median(values))))
        for method, control in [('B','A'),('C','A'),('D','A'),('D','B')]:
            new, old = ranks[method], ranks[control]
            differences = (new<=10).astype(float)-(old<=10).astype(float)
            rng = np.random.default_rng(1110)
            samples = rng.choice(differences, (2000,len(differences)), replace=True).mean(axis=1)*100
            lower, upper = np.percentile(samples,[2.5,97.5])
            comparisons.append(dict(answers=answers, comparison=f'{method} vs {control}',
                                    improved=int(np.sum(new<old)), unchanged=int(np.sum(new==old)),
                                    worsened=int(np.sum(new>old)),
                                    recovered_top10=int(np.sum((new<=10)&(old>10))),
                                    lost_top10=int(np.sum((new>10)&(old<=10))),
                                    delta_recall10_pp=float(differences.mean()*100),
                                    delta_recall10_ci95_low=float(lower), delta_recall10_ci95_high=float(upper)))
    write_csv(output / 'summary.csv', summaries)
    write_csv(output / 'comparisons.csv', comparisons)
    save(output / 'summary.json', dict(metrics=summaries, paired_comparisons=comparisons))
    lines=['# Fixed-state retrieval pilot', '',
           'Same saved PlugIR states, frozen BLIP retriever and 50,000-image corpus for all methods.',
           'The reported effects apply to retrieval at these saved states. New dialogue trajectories and A2R performance have not been evaluated.', '',
           '| Answers | Method | N | R@1 % | R@10 % | R@50 % | MRR |',
           '| --- | --- | --- | --- | --- | --- | --- |']
    for r in summaries:
        lines.append(f"| {r['answers']} | {r['method']} | {r['targets']} | {r['recall_at_1']:.1f} | {r['recall_at_10']:.1f} | {r['recall_at_50']:.1f} | {r['mrr']:.4f} |")
    lines.extend(['','A = current. B = current + 2 variants. C = original + current. D = original + current + variant 1.',
                  'Equal-weight reciprocal rank fusion uses k=60 over complete rankings. Ties use corpus index.',
                  'Paired 95% bootstrap intervals in comparisons.csv resample targets within each stage. Small pilots can have wide or unstable intervals.',
                  'Inspect queries_for_review.csv for added or omitted information. Report invalid generation attempts and truncations from the saved logs.',
                  'Timings are measured with shared query caching and are not independent end-to-end latency measurements for each method.'])
    (output / 'results.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines), flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['prepare','generate','evaluate'])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--split', choices=['smoke','pilot'], required=True)
    parser.add_argument('--device', default=None)
    args=parser.parse_args()
    if args.stage=='prepare':
        prepare(args.output,args.split)
    elif args.stage=='generate':
        generate(args.output,args.split)
    else:
        evaluate(args.output,args.split,args.device)
