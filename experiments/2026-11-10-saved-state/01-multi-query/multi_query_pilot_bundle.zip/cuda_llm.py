"""Sequential, on-device Qwen adapter. No hosted endpoint or API key is used."""

import json
from contextlib import contextmanager
from pathlib import Path
import time
from text_stops import first_stop, stop_sequences, stopped_text


def generation_settings(max_tokens, temperature=0, top_p=1):
    """Preserve PlugIR sampling; override Qwen's repository sampling defaults."""
    settings = dict(max_new_tokens=max_tokens, do_sample=temperature > 0,
                    repetition_penalty=1.0, use_cache=True)
    if temperature > 0:
        settings.update(temperature=temperature, top_p=top_p, top_k=0)
    return settings


def generate_tokens(model, inputs, config, **kwargs):
    # Transformers >=4.50 can otherwise replace explicitly greedy/default values
    # with this repository's do_sample=True, temperature=.7, top_k=20, top_p=.8.
    return model.generate(**inputs, generation_config=config, use_model_defaults=False, **kwargs)


class LocalCUDAChat:
    def __init__(self, model, revision, seed, log_dir, device='cuda:0'):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

        if not torch.cuda.is_available():
            raise RuntimeError('CUDA is unavailable; select a Colab GPU runtime.')
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(model, revision=revision)
        self.device_index = torch.device(device).index or 0
        # The Mac LLM is a separate process. Keep its random stream separate here,
        # too, so caption rewrites do not reset the CPU k-means random stream.
        with torch.random.fork_rng(devices=[self.device_index]):
            torch.manual_seed(seed)
            self.model = AutoModelForCausalLM.from_pretrained(
                model, revision=revision, torch_dtype=torch.float16,
                device_map={'': device}, low_cpu_mem_usage=True,
                attn_implementation='sdpa',
                quantization_config=BitsAndBytesConfig(
                    load_in_4bit=True, bnb_4bit_quant_type='nf4',
                    bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.float16)).eval()
            self.cpu_rng_state = torch.random.get_rng_state()
            self.cuda_rng_state = torch.cuda.get_rng_state(self.device_index)
        self.request_count = 0
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        self.journal = (log_dir / 'llm_requests.jsonl').open('a')
        (log_dir / 'llm_metadata.json').write_text(json.dumps(dict(
            model=model, revision=revision, backend='transformers-cuda',
            quantization='bitsandbytes NF4 double quantization', compute_dtype='float16',
            attention='sdpa', memory_footprint_bytes=self.model.get_memory_footprint(),
            use_model_defaults=False,
            comparison_note='Different quantizer and inference backend from MLX; outputs need not match.'
        ), indent=2) + '\n')

    @contextmanager
    def _random_stream(self, seed):
        import torch
        with torch.random.fork_rng(devices=[self.device_index]):
            torch.random.set_rng_state(self.cpu_rng_state)
            torch.cuda.set_rng_state(self.cuda_rng_state, self.device_index)
            if seed is not None:
                torch.manual_seed(seed)
            try:
                yield
            finally:
                self.cpu_rng_state = torch.random.get_rng_state()
                self.cuda_rng_state = torch.cuda.get_rng_state(self.device_index)

    def create(self, messages, n=1, max_tokens=512, temperature=0, top_p=1, seed=None, stop=None, **kwargs):
        import torch
        from transformers import GenerationConfig

        if kwargs:
            raise ValueError(f'Unsupported local generation parameters: {sorted(kwargs)}')
        choices = []
        sequences = stop_sequences(stop)
        for _ in range(max(n, 1)):
            prompt = self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True)
            inputs = self.tokenizer(prompt, return_tensors='pt', add_special_tokens=False).to(self.device)
            prompt_length = inputs['input_ids'].shape[1]
            config = GenerationConfig(
                **generation_settings(max_tokens, temperature, top_p),
                eos_token_id=self.model.generation_config.eos_token_id,
                pad_token_id=self.tokenizer.pad_token_id,
                bos_token_id=self.tokenizer.bos_token_id)
            generation_kwargs = {}
            if sequences:
                from transformers import StoppingCriteria, StoppingCriteriaList
                tokenizer = self.tokenizer

                class StopText(StoppingCriteria):
                    def __call__(self, input_ids, scores, **unused):
                        text = tokenizer.decode(input_ids[0, prompt_length:].tolist(), skip_special_tokens=True)
                        return first_stop(text, sequences) is not None

                generation_kwargs['stopping_criteria'] = StoppingCriteriaList([StopText()])
            torch.cuda.synchronize(self.device)
            start = time.perf_counter()
            with self._random_stream(seed), torch.inference_mode():
                output = generate_tokens(self.model, inputs, config, **generation_kwargs)
            torch.cuda.synchronize(self.device)
            elapsed = time.perf_counter() - start
            generated = output[0, prompt_length:].tolist()
            raw_text = self.tokenizer.decode(generated, skip_special_tokens=True)
            stopped = first_stop(raw_text, sequences) is not None
            text = stopped_text(raw_text, sequences).strip()
            if not text and not stopped:
                raise RuntimeError('Qwen returned empty text.')
            choice = dict(message=dict(content=text))
            response = dict(choices=[choice], seconds=elapsed, prompt_tokens=prompt_length,
                            generation_tokens=len(generated), hit_token_limit=len(generated) >= max_tokens and not stopped,
                            stopped_by_sequence=stopped,
                            peak_cuda_allocated_gb=torch.cuda.max_memory_allocated(self.device) / 1e9)
            self.request_count += 1
            request = dict(messages=messages, max_tokens=max_tokens, temperature=temperature,
                           top_p=top_p, seed=seed)
            if stop is not None:
                request['stop'] = stop
            self.journal.write(json.dumps(dict(request_id=self.request_count, request=request,
                                               response=response, wall_seconds=elapsed)) + '\n')
            self.journal.flush()
            choices.append(choice)
        return dict(choices=choices)

    def close(self):
        self.journal.close()
