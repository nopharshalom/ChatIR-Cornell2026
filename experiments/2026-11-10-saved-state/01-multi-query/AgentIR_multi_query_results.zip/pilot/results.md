# Fixed-state retrieval pilot

Same saved PlugIR states, frozen BLIP retriever and 50,000-image corpus for all methods.
The reported effects apply to retrieval at these saved states. New dialogue trajectories and A2R performance have not been evaluated.

| Answers | Method | N | R@1 % | R@10 % | R@50 % | MRR |
| --- | --- | --- | --- | --- | --- | --- |
| 4 | A | 100 | 51.0 | 78.0 | 87.0 | 0.6082 |
| 4 | B | 100 | 51.0 | 76.0 | 87.0 | 0.6026 |
| 4 | C | 100 | 47.0 | 76.0 | 92.0 | 0.5612 |
| 4 | D | 100 | 50.0 | 81.0 | 89.0 | 0.5873 |
| 9 | A | 100 | 49.0 | 70.0 | 84.0 | 0.5650 |
| 9 | B | 100 | 48.0 | 70.0 | 85.0 | 0.5629 |
| 9 | C | 100 | 45.0 | 76.0 | 92.0 | 0.5509 |
| 9 | D | 100 | 49.0 | 73.0 | 92.0 | 0.5738 |

A = current. B = current + 2 variants. C = original + current. D = original + current + variant 1.
Equal-weight reciprocal rank fusion uses k=60 over complete rankings. Ties use corpus index.
Paired 95% bootstrap intervals in comparisons.csv resample targets within each stage. Small pilots can have wide or unstable intervals.
Inspect queries_for_review.csv for added or omitted information. Report invalid generation attempts and truncations from the saved logs.
Timings are measured with shared query caching and are not independent end-to-end latency measurements for each method.
