# Fixed-state retrieval pilot

Same saved PlugIR states, frozen BLIP retriever and 50,000-image corpus for all methods.
The reported effects apply to retrieval at these saved states. New dialogue trajectories and A2R performance have not been evaluated.

| Answers | Method | N | R@1 % | R@10 % | R@50 % | MRR |
| --- | --- | --- | --- | --- | --- | --- |
| 4 | A | 10 | 50.0 | 70.0 | 90.0 | 0.5535 |
| 4 | B | 10 | 50.0 | 80.0 | 90.0 | 0.5621 |
| 4 | C | 10 | 60.0 | 90.0 | 100.0 | 0.6569 |
| 4 | D | 10 | 50.0 | 80.0 | 100.0 | 0.5980 |
| 9 | A | 10 | 30.0 | 60.0 | 90.0 | 0.3933 |
| 9 | B | 10 | 10.0 | 50.0 | 90.0 | 0.2629 |
| 9 | C | 10 | 50.0 | 100.0 | 100.0 | 0.6211 |
| 9 | D | 10 | 40.0 | 80.0 | 100.0 | 0.5088 |

A = current. B = current + 2 variants. C = original + current. D = original + current + variant 1.
Equal-weight reciprocal rank fusion uses k=60 over complete rankings. Ties use corpus index.
Paired 95% bootstrap intervals in comparisons.csv resample targets within each stage. Small pilots can have wide or unstable intervals.
Inspect queries_for_review.csv for added or omitted information. Report invalid generation attempts and truncations from the saved logs.
Timings are measured with shared query caching and are not independent end-to-end latency measurements for each method.
